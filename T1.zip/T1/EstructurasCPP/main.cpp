#include<iostream>
// #include"Circle/circle.hpp"

int main(int argc, char const *argv[])
{

    std::cout<<"Area circle: "<< std::endl;
    return 0;
}

//https://cliutils.gitlab.io/modern-cmake/chapters/basics/structure.html